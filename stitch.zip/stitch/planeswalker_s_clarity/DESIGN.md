# Design System: Planeswalker’s Clarity

## 1. Overview & Creative North Star
**Creative North Star: The Archive of the Multiverse**

This design system moves away from the chaotic, texture-heavy "fantasy" aesthetic common in gaming apps. Instead, we embrace an **Editorial Premium** approach. We treat Magic: The Gathering data as high-end scholarship. The goal is to create a digital environment that feels like a clean, illuminated archive where card art is the sole focus. 

We break the "template" look by utilizing **intentional asymmetry** and **tonal depth**. Rather than boxing content into rigid grids with harsh lines, we use expansive white space (breathing room) and overlapping elements to create a sense of discovery and high-end curation.

---

## 2. Colors & Surface Philosophy

The palette is rooted in deep, obsidian slates to allow card illustrations to vibrate with color.

### The "No-Line" Rule
**Borders are prohibited for sectioning.** To define boundaries, use background color shifts. A section of `surface-container-low` sitting on a `surface` background provides all the separation a user needs. This maintains a "seamless" high-end feel.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of obsidian glass.
- **Base Layer:** `surface` (#0e1417)
- **Secondary Containers:** `surface-container` (#1a2024)
- **High-Emphasis Cards:** `surface-container-high` (#252b2e)

### The Glass & Gradient Rule
For floating elements (like Life Counters or Floating Action Buttons), use **Glassmorphism**. Apply a semi-transparent `surface-variant` with a `backdrop-filter: blur(20px)`. 

To provide "soul," use subtle linear gradients for primary actions, transitioning from `primary` (#adc6ff) to `primary-container` (#4b8eff) at a 135-degree angle. This prevents the UI from looking flat and "default."

---

## 3. Typography: Editorial Authority

The typography system creates a dialogue between the modern player and the ancient game.

*   **Display & Headlines (Noto Serif):** Used for card titles and screen headers. This honors the heritage of MTG while the "Clean Serif" execution keeps it modern.
    *   *Headline-LG:* 2rem — Reserved for the most critical page titles.
*   **Body & Labels (Inter):** Used for game mechanics, flavor text, and UI navigation. Inter’s high x-height ensures readability even at `body-sm` (0.75rem) for complex card rulings.
*   **The Contrast Rule:** Always pair a `display-sm` Serif title with a `label-md` Sans-Serif subtitle in `on-surface-variant` to create a sophisticated, editorial hierarchy.

---

## 4. Elevation & Depth

### The Layering Principle
Depth is achieved through **Tonal Layering**. Place a `surface-container-lowest` card on a `surface-container-low` section. This "soft lift" feels more premium than a 1990s-style drop shadow.

### Ambient Shadows
When an element must float (e.g., a card detail modal), use an **Ambient Shadow**:
- **Color:** `surface-container-lowest` (at 40% opacity).
- **Blur:** 40px to 60px.
- **Spread:** -10px.
This mimics natural light reflecting off dark surfaces rather than a "dirty" grey shadow.

### The Ghost Border Fallback
If a border is required for accessibility (e.g., a focus state), use a **Ghost Border**: `outline-variant` at 20% opacity. Never use 100% opaque borders.

---

## 5. Components

### Buttons
*   **Primary:** Gradient of `primary` to `primary-container`. Use `rounded-md` (0.75rem). Text should be `on-primary` (#002e69).
*   **Secondary:** Ghost style. No background, `outline` ghost border, `primary` text.
*   **Tertiary:** `surface-container-highest` background with `on-surface` text. For low-priority utility actions.

### Cards & Deck Lists
**Rule: Forbid divider lines.** 
Separate card entries in a list using the Spacing Scale (specifically `spacing-2` or `spacing-3`). Use a subtle hover state shift to `surface-bright` (#343a3d) to indicate interactivity. Card art should always have a `rounded-sm` (0.25rem) corner to feel "held" by the container.

### Life Totals & Counters
These should be treated as **Hero Elements**. Use `display-lg` (3.5rem) typography. Backgrounds for these containers should use `secondary-container` (#06bb63) for vitality or `tertiary-container` (#ef6719) for hazard states, utilizing a subtle inner-glow to simulate a glowing mana pool.

### Input Fields
Inputs must use `surface-container-highest` with a bottom-only "active" bar in `primary`. This mimics high-end luxury brand forms. Ensure the `label-sm` stays visible at all times for accessibility.

---

## 6. Do's and Don'ts

### Do
*   **Do** use `spacing-6` (2rem) and `spacing-8` (2.75rem) liberally. Negative space is a luxury.
*   **Do** use `secondary` (#4ae183) for all "Gain Life" or "Success" states to ensure high-contrast visibility against the dark background.
*   **Do** use `notoSerif` for numbers in a "Life Counter" context to give them a monumental, epic feel.

### Don't
*   **Don't** use 1px solid lines to separate content. It clutters the "Planeswalker's Clarity."
*   **Don't** use pure black (#000000). Use `surface` (#0e1417) to maintain tonal depth and prevent eye strain.
*   **Don't** use "default" blue. Only use the specified `primary` (#adc6ff) which is tuned for dark-mode accessibility (AAA contrast).